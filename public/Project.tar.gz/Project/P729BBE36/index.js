const signInLink = document.getElementById('sign-in-link');
const signUpLink = document.getElementById('sign-up-link');
const container = document.querySelector('.container');

signUpLink.addEventListener('click', (e) => {
  e.preventDefault();
  container.classList.add('sign-up-mode');
});

signInLink.addEventListener('click', (e) => {
  e.preventDefault();
  container.classList.remove('sign-up-mode');
});